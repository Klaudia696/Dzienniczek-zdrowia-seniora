<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

	<title>Dzienniczek zdrowia seniora</title>
	<link rel="stylesheet" href="style/formularz.css" type="text/css" />

</head>
<body>
	<div style="text-align: center">
	<h1>Dzienniczek zdrowia seniora</h1>
	<dl div style="text-align: center">
	<dt> <a style="font-size: large; line-height: 1cm" href="formUpPac.php?menu=1">Edytuj dane pacjenta</a> </dt>
  <dt> <a style="font-size: large; line-height: 1.2cm" href="formUpPomiar.php?menu=2">Edytuj pomiary</a> </dt>
	<dt> <a style="font-size: large; line-height: 1.2cm" href="usunP.php?menu=2">Usuń pacjenta</a> </dt>
	<dt> <a style="font-size: large; line-height: 1.2cm" href="usunPomiar.php?menu=3">Usuń pomiary</a> </dt>
</dl>
</div>
<div id="layout2"></div>
</body>
</html>
