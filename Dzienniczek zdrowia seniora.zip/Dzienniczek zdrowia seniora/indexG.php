<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

	<title>Dzienniczek zdrowia seniora</title>
	<link rel="stylesheet" href="style/formularz.css" type="text/css" />

</head>
<body>
	<div style="text-align: center">

	<h1>Dzienniczek zdrowia seniora</h1>
	<dl div style="text-align: center">
	<dt> <a style="font-size: large; line-height: 1cm" href="index4.php?menu=1">Zapisz Nowego Pacjenta</a> </dt>
	<dt> <a style="font-size: large; line-height: 1.2cm" href="widok3.php?menu=2">Przeglądaj Dane</a> </dt>
	<dt> <a style="font-size: large; line-height: 1.2cm" href="index .php?menu=3">Aktualizuj Dane</a> </dt>
	<dt> <a style="font-size: large; line-height: 1.2cm" href="edycjaIndex.php?menu=3">Edytuj Dane</a> </dt>
	<dt> <a style="font-size: large; line-height: 1.2cm" href="anomalie.php?menu=3">ANOMALIE</a> </dt>
</dl>
</div>
<div id="layout2"></div>
</body>
</html>
